from tkinter import messagebox
import backup
import os
import shutil

listausus = ()

def validadUsuarioAltair(nombreUsu: str,password:str ,boolGID: bool,boolUID: bool,boolHome: bool,numGID,numUID,home):
    mensajeError = []
    if not nombreUsu or nombreUsu.isspace():
        mensajeError.append("El usuario está vacío o no es una cadena")    
    if not password or password.isspace():
        mensajeError.append("La contraseña está vacía o no es una cadena")
    
    if boolGID == True:
        if numGID < 1000 or numGID > 2000:
            mensajeError.append("Por favor, el GID tiene que estar comprendido entre 1000 y 2000")
    else:
        numGID = None
        
    if boolUID == True:
        if numUID < 1000 or numUID > 2000:
            mensajeError.append("Por favor, el UID tiene que estar comprendido entre 1000 y 2000")
    else:
        numUID = None
        
    if boolHome == True:
        if not home or not isinstance(home, str) or not home.startswith('/'):#Comprobamos que al estar marcado, esté lleno y empiece por la barra /.
            mensajeError.append("El home no puede estar vacío o debe empezar por '/'.")
    #Si no lo está, que coja el valor None.
    else:
        home = None
        
    if mensajeError:
        messagebox.showerror(title = "Error", message = "\n".join(mensajeError))
    else:
        messagebox.showinfo(title="Todo correcto", message="Los valores están bien, proseguimos")
    
def CargarUsuariosAltair():
    salida = subprocess.run(["cut","-d:","-f1","/etc/passwd"], stdout=subprocess.PIPE,stderr=subprocess.PIPE,text = True)
    if salida.returncode == 0:
        ordlineas = sorted(salida.stdout.splitlines())
        for i in ordlineas:
            listausus.append(ordlineas(i))
            return listausus
    else:
        messagebox.showerror(title="Error",message="Error al cargar la lista, abortando")

def ExisteUsuarioAltair(usunom, listausus):
    existe = False
    if usunom in listausus:
        messagebox.showerror(title="Usuario existe",message="El usuario ya existe.")
    return existe

def TipoCopia(src_path, dst_path, tipo_copia) -> None:
    """
    Evalúa el tipo de copia solicitado por el usuario (completa o incremental) y
    realiza la operación llamando a la función RealizarCopiaSeguridad.

    :param tipo_copia: str, tipo de copia ("completa" o "incremental").
    """
    if tipo_copia == "completa":
       RealizarCopiaSeguridad(src_path, dst_path)
    elif tipo_copia == "incremental":
       RealizarCopiaSeguridad(src_path, dst_path,completa=False)
    pass 

def RealizarCopiaSeguridad(src_path, dst_path, completa=True) -> None:
    """
    Realiza la copia de seguridad según el tipo especificado.

    :param src_path: str, ruta del origen de los datos.
    :param dst_path: str, ruta de destino de la copia.
    :param completa: bool, indica si la copia es completa (True) o incremental (False).
    """
    if(os.path.exists(src_path+"/.pybackup")):
        shutil.rmtree(src_path+"/.pybackup")
        print(src_path+"/.pybackup")
    if(os.path.exists(dst_path+"/.pybackup")):
        shutil.rmtree(dst_path+"/.pybackup")
        print(dst_path+"/.pybackup")
    if completa == "completa":
        backup.Backup(src=src_path, dst=dst_path).run()
    elif completa == "incremental":
        backup.IncrementalBackup(src=src_path, dst=dst_path).run()
    else:
        print("Tipo de copia no soportada[!]")
    lanzar_informacion(f"Se ha realizado correctamente una copia de seguridad {completa} 🙌")

def FormatearFecha(fecha) -> list:
    """
    Formatea una fecha en el formato MM/DD/YY separándola en base a "/" y devuelve una lista.

    :param fecha: str, fecha en formato "MM/DD/YY".
    :return: list, componentes de la fecha como ["MM", "DD", "YY"].

    Ejemplo:
    FormatearFecha("2/3/24")
    Output: ["2", "3", "24"]
    """
    fecha_separada = fecha.split("/")
    return fecha_separada

def FormatearTemporalidad(fecha, hora, minuto, dia_semana="*") -> str:

    """
    Formatea la temporalidad de una tarea en el formato requerido por cron.

    Cron utiliza el siguiente formato:

        * * * * * <comando a ejecutar>
        | | | | |
        | | | | day of the week (0–6, Domingo a Sábado; 7 también es Domingo en algunos sistemas)
        | | | month (1–12)
        | | day of the month (1–31)
        | hour (0–23)
        minute (0–59)

    Esta función debe construir una cadena concatenando correctamente los parámetros de entrada.

    :param minuto: str, minuto (0–59).
    :param hora: str, hora (0–23).
    :param dia_mes: str, día del mes (1–31).
    :param mes: str, mes (1–12).
    :param dia_semana: str, día de la semana (0–6, opcional, por defecto "*").
    
    Ejemplo:
    FormatearTemporalidad(31, 21, 10, 2)
    Output: "31 21 10 2 *"
    """
   
    fecha_separada = FormatearFecha(fecha)
    dia_mes = fecha_separada[1]
    mes = fecha_separada [0]
    return minuto + " " + hora + " " + mes  + " " + dia_mes + " " + dia_semana

def ProgramarCopiaSeguridad(fecha, hora, minuto, src_path, dst_path, completa=True) -> None:
    """
    Programa una copia de seguridad añadiendo una línea al fichero de crontab.

    Esta función evalúa el tipo de copia (completa o incremental) y genera el comando adecuado. Luego, utiliza la función
    AñadirTareaCron (no implementada aquí) para registrar el comando con la temporalidad especificada.

    Ejemplo de comandos:
    - Para una copia completa: "cp -r /ruta/origen /ruta/destino"
    - Para una copia incremental: comando específico (e.g., rsync).

    :param Temporalidad: str, cadena con la temporalidad formateada para cron.
    :param completa: bool, indica si la copia es completa (True) o incremental (False).

    """
    temporalidad_formatada = FormatearTemporalidad(fecha, hora, minuto, dia_semana="*")
    usuario = os.popen("whoami").read().strip()
    
    if completa == "completa":
         comando = f"(crontab -u {usuario} -l; echo \"{temporalidad_formatada} cp -r {src_path} {dst_path}\") | crontab -u {usuario} -"
         print(comando)
         os.system(comando)
    elif completa == "incremental":
        comando = f"(crontab -u {usuario} -l; echo \"{temporalidad_formatada} rsync -a --ignore-existing {src_path} {dst_path}\") | crontab -u {usuario} -"
        print(comando)
        os.system(comando)
    lanzar_informacion(f"Se ha programado una copia de seguridad {completa} correctamente 🙌")

def lanzar_error(texto_error):
    messagebox.showerror(title="Error", message=texto_error)

def lanzar_informacion(texto_informativo):
    messagebox.showinfo(title="Información", message=texto_informativo)

