from tkinter import messagebox
import backup
import os
import shutil
import subprocess
import crypt
import sys

#Ruben

listausus = []

def validadUsuarioAltair(nombreUsu: str,password:str ,boolGID: bool,boolUID: bool,boolHome: bool,numGID,numUID,home):
    mensajeError = []
    if not nombreUsu or nombreUsu.isspace():
        mensajeError.append("El usuario está vacío o no es una cadena")    
    if not password or password.isspace():
        mensajeError.append("La contraseña está vacía o no es una cadena")
    
    if boolGID == True:
        if not numGID or str(numGID).isspace():
            mensajeError.append("Por favor, el GID tiene que ser una string.")
    else:
        numGID = None
        
    if boolUID == True:
        if not numUID or numUID < 1000 or numUID > 2000:
            mensajeError.append("Por favor, el UID tiene que estar comprendido entre 1000 y 2000")
    else:
        numUID = None
        
    if boolHome == True:
        if not home or not isinstance(home, str) or not home.startswith('/'):#Comprobamos que al estar marcado, esté lleno y empiece por la barra /.
            mensajeError.append("El home no puede estar vacío o debe empezar por '/'.")
    #Si no lo está, que coja el valor None.
    else:
        home = None
        
    if mensajeError:
        return mensajeError
    else:
        return None

def CargarUsuariosAltair():
    listausus = []
    salida = subprocess.run(["cut","-d:","-f1","/etc/passwd"], stdout=subprocess.PIPE,stderr=subprocess.PIPE,text = True)
    if salida.returncode == 0:
        ordlineas = sorted(salida.stdout.splitlines())
        for i in ordlineas:
            listausus.append(i)
        return listausus
    else:
        messagebox.showerror(title="Error",message="Error al cargar la lista, abortando")

def ExisteUsuarioAltair(usunom, listausus):
    if usunom in listausus:
        return True
    return False

def borrarUsu(usunom):
    lista = CargarUsuariosAltair()
    existe = ExisteUsuarioAltair(usunom,lista)
    if existe == True:
       confirmacion = messagebox.askyesno(title="Borrar usuario",message="¿Estás seguro de querer borrar el usuario?")
       if confirmacion == True:
           procesoBorrar = subprocess.run(["userdel", "-r",usunom],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
           if procesoBorrar.returncode == 0:
               return messagebox.showinfo(title="Borrado",message="El Usuario ha sido borrado.")
           else:
               return messagebox.showerror(title="Borrado",message="Error al borrar el usuario.")
       else:
           return messagebox.showinfo(title="Borrado",message="Proceso de borraro detenido.")
    else:
        return messagebox.showinfo(title="Borrado",message="El usuario no existe")

def crearUsuario(nombreusu,password,boolGID,boolUID,boolHOME,numGID = None, numUID = None, home = None):
    mensajeError =validadUsuarioAltair(nombreusu,password,boolGID,boolUID,boolHOME,numGID,numUID,home)
    lista = CargarUsuariosAltair()
    existe = ExisteUsuarioAltair(nombreusu,lista)
    contraEncriptada = crypt.crypt(password)
    command = ["useradd", "-p", contraEncriptada,]

    if mensajeError:
        messagebox.showerror(title="Error",message=mensajeError)
    else:
        if existe:
            messagebox.showerror(title="Error",message="El usuario ya existe.")
        else:
            if boolGID and numGID:
                subprocess.run(["groupadd",numGID],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                command.extend(["-g", str(numGID)])
            if boolUID and numUID:
                command.extend(["-u",str(numUID)])
            if boolHOME and home:
                command.extend(["-m","-d",home])

            command.extend([nombreusu])
            procesocrear = subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)

            if procesocrear.returncode == 0:
                messagebox.showinfo(title="Usuario creado",message=f"Usuario {nombreusu} creado correctamente")
            else:
                messagebox.showerror(title="Error al crear",message=f"Error: {procesocrear.stderr}")

#Isaac 

def validarCamposRigel(src_path, dst_path, fecha=0, hora=0, minuto=0):
    mensajeError = ""
    if src_path == "":
        mensajeError = mensajeError + "• Falta la ruta de origen\n"
    if dst_path == "":
        mensajeError = mensajeError + "• Falta la ruta de destino\n"
    if fecha == "" or fecha == " ":
        mensajeError = mensajeError + "• Falta la fecha\n"
    if hora == "" or hora == " ":
        mensajeError = mensajeError + "• Falta las horas\n"
    if minuto == "" or minuto == " ":
        mensajeError = mensajeError + "• Faltan los minutos\n" 
    return mensajeError.rstrip("\n")


def TipoCopia(src_path, dst_path, tipo_copia) -> None:
    """
    Evalúa el tipo de copia solicitado por el usuario (completa o incremental) y
    realiza la operación llamando a la función RealizarCopiaSeguridad.

    :param tipo_copia: str, tipo de copia ("completa" o "incremental").
    """
    if tipo_copia == "completa":
       RealizarCopiaSeguridad(src_path, dst_path)
    elif tipo_copia == "incremental":
       RealizarCopiaSeguridad(src_path, dst_path,completa=False)
    pass 

def RealizarCopiaSeguridad(src_path, dst_path, completa=True) -> None:
    """
    Realiza la copia de seguridad según el tipo especificado.

    :param src_path: str, ruta del origen de los datos.
    :param dst_path: str, ruta de destino de la copia.
    :param completa: bool, indica si la copia es completa (True) o incremental (False).
    """
    try:
        for path in [src_path, dst_path]:
            backup_path = os.path.join(path, ".pybackup")
            if os.path.exists(backup_path):
                shutil.rmtree(backup_path)

        mensajes_error = validarCamposRigel(src_path, dst_path)

        if len(mensajes_error) >= 1:
            lanzar_error(mensajes_error)
            return
        else:
            if completa == "completa":
                backup.Backup(src=src_path, dst=dst_path).run()
            elif completa == "incremental":
                stderr = sys.stderr
                stdout = sys.stdout

                sys.stdout = open(os.devnull, 'w')
                sys.stderr = open(os.devnull, 'w')
                backup.IncrementalBackup(src=src_path, dst=dst_path).run()
                sys.stderr = stderr
                sys.stdout = stdout
            else:
                lanzar_error("Tipo de copia no soportada[!]")
            lanzar_informacion(f"Se ha realizado correctamente una copia de seguridad {completa} 🙌")
    except:
        lanzar_error("Ha surgido un error inesperado al intentar realizar una copia de seguridad.")

def FormatearFecha(fecha) -> list:
    """
    Formatea una fecha en el formato MM/DD/YY separándola en base a "/" y devuelve una lista.

    :param fecha: str, fecha en formato "MM/DD/YY".
    :return: list, componentes de la fecha como ["MM", "DD", "YY"].

    Ejemplo:
    FormatearFecha("2/3/24")
    Output: ["2", "3", "24"]
    """
    fecha_separada = fecha.split("/")
    return fecha_separada

def FormatearTemporalidad(fecha, hora, minuto, dia_semana="*") -> str:

    """
    Formatea la temporalidad de una tarea en el formato requerido por cron.

    Cron utiliza el siguiente formato:

        * * * * * <comando a ejecutar>
        | | | | |
        | | | | day of the week (0–6, Domingo a Sábado; 7 también es Domingo en algunos sistemas)
        | | | month (1–12)
        | | day of the month (1–31)
        | hour (0–23)
        minute (0–59)

    Esta función debe construir una cadena concatenando correctamente los parámetros de entrada.

    :param minuto: str, minuto (0–59).
    :param hora: str, hora (0–23).
    :param dia_mes: str, día del mes (1–31).
    :param mes: str, mes (1–12).
    :param dia_semana: str, día de la semana (0–6, opcional, por defecto "*").
    
    Ejemplo:
    FormatearTemporalidad(31, 21, 10, 2)
    Output: "31 21 10 2 *"
    """
   
    fecha_separada = FormatearFecha(fecha)
    dia_mes = fecha_separada[1]
    mes = fecha_separada [0]
    return minuto + " " + hora + " " + mes  + " " + dia_mes + " " + dia_semana

def ProgramarCopiaSeguridad(fecha, hora, minuto, src_path, dst_path, completa=True) -> None:
    """
    Programa una copia de seguridad añadiendo una línea al fichero de crontab.

    Esta función evalúa el tipo de copia (completa o incremental) y genera el comando adecuado. Luego, utiliza la función
    AñadirTareaCron (no implementada aquí) para registrar el comando con la temporalidad especificada.

    Ejemplo de comandos:
    - Para una copia completa: "cp -r /ruta/origen /ruta/destino"
    - Para una copia incremental: comando específico (e.g., rsync).

    :param Temporalidad: str, cadena con la temporalidad formateada para cron.
    :param completa: bool, indica si la copia es completa (True) o incremental (False).

    """
    try:
        temporalidad_formatada = FormatearTemporalidad(fecha, hora, minuto, dia_semana="*")
        usuario = os.popen("whoami").read().strip()
        
        mensajes_error = validarCamposRigel(src_path, dst_path, fecha, hora, minuto)
        if len(mensajes_error) >= 1:
            lanzar_error(mensajes_error)
            return
        else:
            if completa == "completa":
                comando = f"(crontab -u {usuario} -l; echo \"{temporalidad_formatada} cp -r {src_path} {dst_path}\") | crontab -u {usuario} -"
                os.system(comando)
            elif completa == "incremental":
                comando = f"(crontab -u {usuario} -l; echo \"{temporalidad_formatada} rsync -a --ignore-existing {src_path} {dst_path}\") | crontab -u {usuario} -"
                os.system(comando)
            lanzar_informacion(f"Se ha programado una copia de seguridad {completa} correctamente 🙌")
    except:
        lanzar_error("Ha surgido un error inesperado al intentar programar una copia de seguridad.")
#Jose

def cargar_usuarios():
    usuarios= []
    resultado = subprocess.run(["cut", "-d:", "-f1", "/etc/passwd"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if resultado.returncode == 0:
        for lineas in resultado.stdout.splitlines():
                usuarios.append(lineas.rstrip())
    else:
        lanzar_error("Error obteniendo los usuarios del sistema: " + str(resultado.stderr.splitlines()))
    return usuarios

def usuario_en_sistema(nombre_usuario, usuarios):
    if len(usuarios) != 0:
        if nombre_usuario in usuarios:  # Lista de usuarios validos
            return True
        else:
            lanzar_error("Usuario no está en el sistema")
    else:
        lanzar_error("No hay usuarios en el sistema")
    return False

def leer_fichero_cron(usuario):
    resultado = subprocess.run(["crontab", "-l", "-u", usuario], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False)
    tasks = []
    if resultado.returncode == 0:
        for lineas in resultado.stdout.splitlines():
            if lineas and not lineas.startswith("#") and lineas.strip():
                tasks.append(lineas.lstrip().rstrip())
    else:
        lanzar_error(f"Error de crontab para el usuario {usuario}. Code error: " + str(resultado.stderr))
    return tasks

def escribir_fichero_cron(tabla, usuario):
    tabla_lista = []
    for linea in tabla:
        tabla_lista.append(linea[1] + " " + linea[0])
    
    resultado = subprocess.run([f"crontab", "-u", usuario, "-"],
                                input= str("\n".join(tabla_lista) + "\n"), #Necesita un "\n" al final de cada linea de cada task, para que crontab funcione bien 
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True)
    if resultado.returncode == 0:
        lanzar_informacion(f"Se ha sobreescrito el fichero de crontab de {usuario} con el contenido actual de la tabla.")
    else:
        lanzar_error("Error escribiendo en el fichero de crontab: " + str(resultado.stderr.splitlines()))

def formatear_task(frecuencia):
    frecuencias_cron = {
        "Cada dia": "0 0 * * *",
        "Cada hora": "0 * * * *",
        "Cada semana": "0 0 * * 0",
        "Cada mes": "0 0 1 * *",
        "Cada año": "0 0 1 1 *"
    }
    return str(frecuencias_cron.get(frecuencia))

def validar_task(frecuencia):
    formateada = frecuencia.split(" ")
    errores = []
    dias_validos = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
    meses_validos = ("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")
    simbolos_validos = ("*", "~")

    if len(formateada) != 5:
        errores.append(f"Debe haber 5 campos, revisa los espacios en blanco. 👍")
    else:
        campos = {"minutos": formateada[0], "horas": formateada[1],"dia_del_mes": formateada[2], "mes": formateada[3], "dia_de_la_semana": formateada[4]}
        for clave, valor in campos.items():
            if valor == "":
                errores.append(f"Campo {clave} vacío.")
            if "," in valor:
                lista = valor.split(",")
                error = validar_lista(lista, clave, simbolos_validos, meses_validos, dias_validos)
                if error:
                    errores.append(error)
            elif "-" in valor:
                lista = valor.split("-")
                if len(lista) == 2:
                    error = validar_lista(lista, clave, simbolos_validos, meses_validos, dias_validos)
                    if error:#AQUI
                        errores.append(error)
                else:
                    errores.append("Solo puedes meter dos elementos en el rango 👅.")
            elif "/" in valor:
                lista = valor.split("/")
                if len(lista) == 2 and (lista[0] == "*" and lista[1].isdigit()):
                    error = validar_lista(lista, clave, simbolos_validos, meses_validos, dias_validos)
                    if error:
                        errores.append(error)
                else:
                    errores.append("El primer caracter tiene que ser un * y el segundo un número. (◕‿◕)")
            else:
                error = validar_lista([valor], clave, simbolos_validos, meses_validos, dias_validos)
                if error:
                    errores.append(error)
    return "\n".join(errores)

def valida_minutos(minutos, simbolos_validos):
    if minutos == "" or (minutos not in str(list(range(0, 60))) and minutos not in simbolos_validos):
        return "Los minutos deben estar entre 0-59"

def valida_horas(horas, simbolos_validos):
    if horas == "" or (horas not in str(list(range(0, 24))) and horas not in simbolos_validos):
        return "Las horas deben estar entre 0-23."    

def valida_dia_del_mes(dia_del_mes, simbolos_validos):
    if dia_del_mes == "" or(dia_del_mes not in str(list(range(1, 32))) and dia_del_mes not in simbolos_validos):
        return "Los dias del mes deben estar entre 1-31."      

def valida_mes(mes, simbolos_validos, meses_validos):
    if mes == "" or(mes not in str(list(range(1, 13))) and mes.lower() not in meses_validos and mes.lower() not in simbolos_validos):
        return "Los meses deben estar entre 1-12 o entre jan-dec."    

def valida_dias_de_la_semana(dia_de_la_semana, simbolos_validos, dias_validos):
    if dia_de_la_semana == "" or(dia_de_la_semana not in str(list(range(0, 7))) and dia_de_la_semana.lower() not in dias_validos and dia_de_la_semana.lower() not in simbolos_validos):
        return "Los dias de la semana deben estar entre mon-sun o entre 0-6."

def validar_lista(lista, clave, simbolos_validos, meses_validos, dias_validos):
    errores = []
    for id, campo_lista in enumerate(lista):  # Aquí usamos enumerate(lista)
        if clave == "minutos":
            minutos = valida_minutos(campo_lista, simbolos_validos)
            if minutos:
                errores.append(f"{minutos} Fallo en el elemento {id+1}.")
        if clave == "horas":
            horas = valida_horas(campo_lista, simbolos_validos)
            if horas:
                errores.append(f"{horas} Fallo en el elemento {id+1}.")
        if clave == "dia_del_mes":
            dia_mes = valida_dia_del_mes(campo_lista, simbolos_validos)
            if dia_mes:
                errores.append(f"{dia_mes} Fallo en el elemento {id+1}.")
        if clave == "mes":
            mes = valida_mes(campo_lista, simbolos_validos, meses_validos)
            if mes:
                errores.append(f"{mes} Fallo en el elemento {id+1}.")
        if clave == "dia_de_la_semana":
            dia_semana = valida_dias_de_la_semana(campo_lista, simbolos_validos, dias_validos)
            if dia_semana:
                errores.append(f"{dia_semana} Fallo en el elemento {id+1}.")
    return "\n".join(errores)



def lanzar_error(texto_error):
    messagebox.showerror(title="Error", message=texto_error)

def lanzar_informacion(texto_informativo):
    messagebox.showinfo(title="Información", message=texto_informativo)

