import customtkinter as ctk
import tkinter as tk
from tkcalendar import DateEntry
from tkinter import filedialog
import json
import TaskCront as taskC
from tkinter import messagebox
import tree_view
from PIL import Image, ImageTk
import Utils 

with open("AppConfigurations/config.json") as json_file:
    DATA = json.load(json_file)
    APP_COLORS = DATA["APP_COLORS"]
    APP_DIMENSIONS = DATA["DIMENSIONS"]

ctk.set_appearance_mode("dark")
# Colores
Outter_Frame_Color = APP_COLORS["Frame"]["Primary"]
Inner_Frame_Color = APP_COLORS["Frame"]["Secondary"]
In_Inner_Frame_Color = APP_COLORS["Frame"]["Terciary"]

Title_Color = APP_COLORS["Text"]["Title"]
Text_Color = APP_COLORS["Text"]["Primary"]

Button_Color = APP_COLORS["Button"]["Primary"]
Button_Hover_Color = APP_COLORS["Hover"]["Primary"]

Border_Color = APP_COLORS["Border"]["Primary"]

xl_font = ("Times New Roman", 35)
lg_font = ("Times New Roman", 19)

SideBar_Color = APP_COLORS["SideBar"]["Primary"]
SideBar_Button_Color = APP_COLORS["SideBar"]["Secondary"]
SideBar_Active_Color = APP_COLORS["SideBar"]["Active"]
SideBar_ActiveHover_Color = APP_COLORS["SideBar"]["Active_Hover"]

Screen_Width = APP_DIMENSIONS['Width']
Screen_Height = APP_DIMENSIONS['Height']

# --------------------------------------
def clean_frame(frame):
    for widget in frame.winfo_children():
        widget.destroy()

def responsive_grid(frame):
        last_row_id = ""
        last_column_id = ""
        for widget in frame.winfo_children():
            last_row_id = widget.grid_info()["row"]
            last_column_id = widget.grid_info()["column"]
        for i in range(0, last_row_id + 1):
            frame.rowconfigure(i, weight=1)
        for i in range(0, last_column_id + 1):
            frame.columnconfigure(i, weight=1)

def cargar_tabla(tabla,lista_tasks):
        for task in lista_tasks:
            tabla.insert(
                "",
                "end",
                text=task.get_nombre(),
                values=[task.get_comando(), task.get_frecuencia()]
            )

def lanzar_error(texto_error):
    messagebox.showerror(title="Error", message=texto_error)

def lanzar_informacion(texto_informativo):
    messagebox.showinfo(title="Información", message=texto_informativo)

InitialState = 1

def default_frame_set_up(frame):
    global InitialState
    clean_frame(frame)
    if InitialState:
        wrapper_frame.configure(fg_color=Outter_Frame_Color,scrollbar_button_color="#6c6c6c",scrollbar_button_hover_color="#878787")
        wrapper_frame.pack(expand=True, fill="both", side="right", padx=8, pady=8)
        InitialState = 0
    return

def select_folder(entry_widget):
    selected_path = filedialog.askdirectory()
    entry_widget.configure(state="normal")
    entry_widget.delete(0, "end")
    entry_widget.insert(0, selected_path)
    entry_widget.configure(state="disabled")

def backup_mode(action_id,source_entry,destination_entry,backup_type, hora=0, minuto=0, fecha=0):
    if action_id == 1:
        Utils.RealizarCopiaSeguridad(source_entry,destination_entry,backup_type.lower())
    elif action_id == 2:
        Utils.ProgramarCopiaSeguridad(fecha, hora, minuto, source_entry, destination_entry, backup_type.lower())

def current_active_button(Current_Frame):
    list_buttons = {
        "Isaac_Instanteo": InstantCopyButton,
        "Isaac_Periodico": PeriodicCopyButton,
        "Ruben": LDAPUsersButton,
        "Jose": CronButton,
    }
    list_buttons.get(Current_Frame).configure(fg_color=SideBar_Active_Color, text_color="#FFFFFF", hover_color=SideBar_ActiveHover_Color)
    for key in list_buttons:
        if key != Current_Frame:
            list_buttons.get(key).configure(
                fg_color=SideBar_Button_Color,
                text_color="#FFFFFF",
                hover_color=SideBar_Active_Color,
            )

def setup_app_widgets_isaac(main_frame, signal):
    """
    Configura los widgets de la aplicación.
    """
    default_frame_set_up(main_frame)

    main_frame.pack(expand=True, fill="both")
    # Título principal
    title_label = ctk.CTkLabel(
        main_frame,
        text="Equipo Rigel 🚀",
        text_color=Title_Color,
        font=("Times New Roman", 35),
    )
    title_label.pack(side="top")

    def periodic_copy(main_frame):
        # --- Sección: Copia de seguridad inmediata ---
        immediate_backup_frame = ctk.CTkFrame(
            master=main_frame,
            fg_color=Inner_Frame_Color,
            border_color=Border_Color,
            border_width=1,
        )

        immediate_backup_label = ctk.CTkLabel(
            immediate_backup_frame,
            text="Crear una copia de\nseguridad en el momento",
            text_color=Text_Color,
            font=("Times New Roman", 19, "italic", "bold"),
            padx=10,  # para que no se corte el titulo por el lado derecho..
        )

        # Selección de ruta de origen
        source_label = ctk.CTkLabel(
            immediate_backup_frame,
            text="Ruta de Origen",
            text_color=Text_Color,
            font=lg_font,
        )

        source_entry = ctk.CTkEntry(
            immediate_backup_frame,
            placeholder_text="Ruta de Origen",
            state="disabled",
        )

        source_button = ctk.CTkButton(
            immediate_backup_frame,
            text="Elige ruta",
            command=lambda: select_folder(source_entry),
            fg_color=Button_Color,
            border_color=Border_Color,
            border_width=1,
            hover_color=Button_Hover_Color,
            font=lg_font,
        )

        # Selección de ruta de destino
        destination_label = ctk.CTkLabel(
            immediate_backup_frame,
            text="Ruta de Destino",
            text_color=Text_Color,
            font=lg_font,
        )

        destination_entry = ctk.CTkEntry(immediate_backup_frame, placeholder_text="Ruta de Destino", state="disabled")

        destination_button = ctk.CTkButton(
            immediate_backup_frame,
            text="Elige ruta",
            command=lambda: select_folder(destination_entry),
            fg_color=Button_Color,
            border_color=Border_Color,
            border_width=1,
            hover_color=Button_Hover_Color,
            font=lg_font,
        )

        # Tipo de copia de seguridad
        backup_type_label = ctk.CTkLabel(
            immediate_backup_frame,
            text="Tipo de copia de seguridad",
            text_color=Text_Color,
            font=lg_font,
        )

        backup_type_var = tk.StringVar(value="Incremental")

        incremental_backup_radio = ctk.CTkRadioButton(
            immediate_backup_frame,
            text="Incremental",
            variable=backup_type_var,
            value="Incremental",
            font=lg_font,
            fg_color=Button_Color,
            hover_color=Button_Hover_Color,
        )

        full_backup_radio = ctk.CTkRadioButton(
            immediate_backup_frame,
            text="Completa",
            variable=backup_type_var,
            value="Completa",
            font=lg_font,
            fg_color=Button_Color,
            hover_color=Button_Hover_Color,
        )

        create_backup_button = ctk.CTkButton(
            immediate_backup_frame,
            text="Crear copia",
            fg_color=Button_Color,
            border_color=Border_Color,
            border_width=1,
            hover_color=Button_Hover_Color,
            command=lambda: backup_mode(1,source_entry.get(),destination_entry.get(),backup_type_var.get()),
            font=lg_font,
        )

        immediate_backup_frame.pack(expand=True, side="top", fill="both", padx=20, pady=40)
        immediate_backup_label.pack(side="top", pady=5)
        source_label.pack(side="top", anchor="w", padx=20, pady=5)
        source_entry.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        source_button.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        destination_label.pack(side="top", anchor="w", padx=20, pady=5)
        destination_entry.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        destination_button.pack(side="top", anchor="w", fill="x", padx=20, pady=5)

        backup_type_label.pack(side="top", anchor="w", padx=20, pady=5)
        incremental_backup_radio.pack(side="top", anchor="w", padx=40, pady=5)
        full_backup_radio.pack(side="top", anchor="w", padx=40, pady=5)

        create_backup_button.pack(side="top", fill="x", padx=20, pady=(10, 25))

        return main_frame

    def instant_copy(main_frame):

        # --- Sección: Programar copia de seguridad ---
        schedule_backup_frame = ctk.CTkFrame(
            master=main_frame,
            fg_color=Inner_Frame_Color,
            border_color=Border_Color,
            border_width=1,
        )

        schedule_backup_label = ctk.CTkLabel(
            schedule_backup_frame,
            text="Programar una copia\nde seguridad",
            text_color=Text_Color,
            font=("Times New Roman", 19, "italic", "bold"),
            padx=10,  # para que no se corte el titulo por el lado derecho..
        )

        # Selección de ruta de origen programada
        scheduled_source_label = ctk.CTkLabel(
            schedule_backup_frame,
            text="Ruta de Origen",
            text_color=Text_Color,
            font=lg_font,
        )

        scheduled_source_entry = ctk.CTkEntry(schedule_backup_frame, placeholder_text="Ruta de Origen", state="disabled")

        scheduled_source_button = ctk.CTkButton(
            schedule_backup_frame,
            text="Elige ruta",
            command=lambda: select_folder(scheduled_source_entry),
            fg_color=Button_Color,
            border_color=Border_Color,
            border_width=1,
            font=lg_font,
            hover_color=Button_Hover_Color,
        )

        # Selección de ruta de destino programada
        scheduled_destination_label = ctk.CTkLabel(
            schedule_backup_frame,
            text="Ruta de Destino",
            text_color=Text_Color,
            font=lg_font,
        )

        scheduled_destination_entry = ctk.CTkEntry(schedule_backup_frame, placeholder_text="Ruta de Destino", state="disabled")

        scheduled_destination_button = ctk.CTkButton(
            schedule_backup_frame,
            text="Elige ruta",
            border_color=Border_Color,
            border_width=1,
            command=lambda: select_folder(scheduled_destination_entry),
            fg_color=Button_Color,
            hover_color=Button_Hover_Color,
            font=lg_font,
        )

        # Tipo de copia de seguridad
        scheduled_type_label = ctk.CTkLabel(
            schedule_backup_frame,
            text="Tipo de copia de seguridad",
            text_color=Text_Color,
            font=lg_font,
        )

        scheduled_backup_type_var = tk.StringVar(value="Incremental")

        scheduled_incremental_backup_radio = ctk.CTkRadioButton(
            schedule_backup_frame,
            text="Incremental",
            variable=scheduled_backup_type_var,
            value="Incremental",
            fg_color=Button_Color,
            hover_color=Button_Hover_Color,
            font=lg_font,
        )

        scheduled_full_backup_radio = ctk.CTkRadioButton(
            schedule_backup_frame,
            text="Completa",
            variable=scheduled_backup_type_var,
            value="Completa",
            font=lg_font,
            fg_color=Button_Color,
            hover_color=Button_Hover_Color,
        )

        # Fecha y hora programadas
        schedule_date_label = ctk.CTkLabel(
            schedule_backup_frame,
            text="Hora programable",
            text_color=Text_Color,
            font=lg_font,
        )

        schedule_date_date = DateEntry(schedule_backup_frame, width=30, year=2025)

        schedule_date_hour = ctk.CTkEntry(schedule_backup_frame, placeholder_text="Hora de copia")
        schedule_date_minute = ctk.CTkEntry(schedule_backup_frame, placeholder_text="Minuto de copia")

        schedule_backup_button = ctk.CTkButton(
            schedule_backup_frame,
            text="Programar copia",
            fg_color=Button_Color,
            border_color=Border_Color,
            border_width=1,
            hover_color=Button_Hover_Color,
            command=lambda: backup_mode(2,scheduled_source_entry.get(), scheduled_destination_entry.get(), scheduled_backup_type_var.get(), schedule_date_hour.get(), schedule_date_minute.get(), schedule_date_date.get()),
            font=lg_font,
        )

        schedule_backup_frame.pack(expand=True, side="top", fill="both", padx=20, pady=40)
        schedule_backup_label.pack(side="top", pady=5)
        scheduled_source_label.pack(side="top", anchor="w", padx=20, pady=5)
        scheduled_source_entry.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        scheduled_source_button.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        scheduled_destination_label.pack(side="top", anchor="w", padx=20, pady=5)
        scheduled_destination_entry.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        scheduled_destination_button.pack(side="top", anchor="w", fill="x", padx=20, pady=5)

        scheduled_type_label.pack(side="top", anchor="w", padx=20, pady=5)
        scheduled_incremental_backup_radio.pack(side="top", anchor="w", padx=40, pady=5)
        scheduled_full_backup_radio.pack(side="top", anchor="w", padx=40, pady=5)

        schedule_date_label.pack(side="top", anchor="w", padx=20, pady=5)
        schedule_date_hour.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        schedule_date_minute.pack(side="top", anchor="w", fill="x", padx=20, pady=5)
        schedule_date_date.pack(side="top", anchor="w", padx=20, pady=5)
        schedule_backup_button.pack(side="top", fill="x", padx=20, pady=(10, 25))

        return main_frame

    if signal == 1:
        current_active_button("Isaac_Periodico")
        instant_copy(main_frame)
    else:
        current_active_button("Isaac_Instanteo")
        periodic_copy(main_frame)

def setup_app_widgets_ruben(main_frame):
    boolGID = None
    boolUID = None
    boolHome = None
    numGID = 0
    numUID = 0
    pathHome = ""
    default_frame_set_up(main_frame)
    current_active_button("Ruben")
        # Título principal
    FrameTitulo = ctk.CTkLabel(
        main_frame,
        text="Equipo Altair ☀",
        text_color=Title_Color,
        font=xl_font,
    )

    FrameTitulo.pack(padx=20,pady=(0,20), anchor="center")
    main_frame.pack(expand=True, fill="both", padx=8, pady=8)
    # Título, estará dentro de un frame.
    

    # Frame Datos.
    frameDatos = ctk.CTkFrame(master=main_frame, fg_color=Inner_Frame_Color, width=500, height=200,border_color=Border_Color,border_width=1)
    frameDatos.pack(pady=1, fill="both", expand=True, padx=30)
    titulo = ctk.CTkLabel(
        frameDatos,
        text="Gestión de usuarios",
        fg_color="transparent",
        font=xl_font,
        text_color="#ffffff",
    )
    titulo.pack(padx=20, pady=20, anchor="center")
    # Nombre usuario
    usu = ctk.CTkLabel(
        frameDatos,
        text="Nombre de usuario",
        fg_color="transparent",
        font=lg_font,
        text_color="#ffffff",
    )
    usu.pack(padx=10, pady=(10, 0))
    usunom = ctk.CTkEntry(frameDatos, placeholder_text="Nombre...")
    usunom.pack(padx=10, expand=True, fill="x")

    # Contraseña
    passwd = ctk.CTkLabel(
        frameDatos,
        text="Contraseña",
        fg_color="transparent",
        font=lg_font,
        text_color="#ffffff",
    )
    passwd.pack(padx=10, pady=(10, 0))
    passwdent = ctk.CTkEntry(frameDatos, placeholder_text="Contraseña...", show = "*")
    passwdent.pack(padx=10, expand=True, fill="x")

    # GID
    # Evento para luego deshabilitar cada checkbox

    def checkbox_event_GID():
        nonlocal boolGID
        nonlocal numGID
        if check_var.get() == "on":
            gidEnt.configure(state="normal")
            try:
                numGID = gidEnt.get()
            except ValueError:
                lanzar_error("Tiene que ser una cadena de caracteres")
            boolGID = True
        else:
            gidEnt.configure(state="disabled")
            boolGID= False
            

    check_var = ctk.StringVar(value="on")

    gid = ctk.CTkLabel(
        frameDatos,
        text="GID",
        fg_color="transparent",
        font=lg_font,
        text_color="#ffffff",
    )
    gid.pack(padx=10, pady=(10, 0))
    gidFrame = ctk.CTkFrame(master=frameDatos, fg_color=Inner_Frame_Color, width=500, height=200)
    gidFrame.pack(fill="x", padx=20)
    checkbox_GID = ctk.CTkCheckBox(
        gidFrame,
        text="Activar GID personalizada",
        command=checkbox_event_GID,
        variable=check_var,
        onvalue="on",
        offvalue="off",
        text_color="#ffffff",
        fg_color=Button_Color,
        hover_color=Button_Hover_Color
    )
    checkbox_GID.grid(column=0, row=0)
    gidEnt = ctk.CTkEntry(gidFrame)
    gidEnt.grid(column=1, row=0, padx=(23, 0), sticky="nsew")
    responsive_grid(gidFrame)
    # UID
    # Evento para luego deshabilitar cada checkbox
    def checkbox_event_UID():
        nonlocal boolUID
        nonlocal numUID
        if check_var_UID.get() == "on":
            uidEnt.configure(state="normal")
            try:
                numUID = int(uidEnt.get())
            except ValueError:
                lanzar_error("Tiene que ser un número válido")
            boolUID = True
        else:
            uidEnt.configure(state="disabled")
            boolUID = False
            

    check_var_UID = ctk.StringVar(value="on")

    uid = ctk.CTkLabel(
        frameDatos,
        text="UID",
        fg_color="transparent",
        font=lg_font,
        text_color="#ffffff",
    )
    uid.pack(padx=10, pady=(10, 0))
    uidFrame = ctk.CTkFrame(master=frameDatos, fg_color=Inner_Frame_Color, width=500, height=200)
    uidFrame.pack(fill="x", padx=20)
    checkbox_UID = ctk.CTkCheckBox(
        uidFrame,
        text="Activar UID personalizada",
        command=checkbox_event_UID,
        variable=check_var_UID,
        onvalue="on",
        offvalue="off",
        text_color="#ffffff",
        fg_color=Button_Color,
        hover_color=Button_Hover_Color
    )
    checkbox_UID.grid(column=0, row=0)
    uidEnt = ctk.CTkEntry(uidFrame)
    uidEnt.grid(column=1, row=0, padx=(23, 0), sticky="nsew")
    responsive_grid(uidFrame)
    # Home
    check_var_home = ctk.StringVar(value="on")

    def checkbox_event_home():
        nonlocal boolHome
        nonlocal pathHome
        if check_var_home.get() == "on":
            homeEnt.configure(state="normal")
            pathHome = homeEnt.get().strip()
            boolHome = True
        else:
            homeEnt.configure(state="disabled")
            boolHome = False
            

    home = ctk.CTkLabel(
        frameDatos,
        text="Home",
        fg_color="transparent",
        font=lg_font,
        text_color="#ffffff",
    )
    home.pack(padx=10)
    homeFrame = ctk.CTkFrame(master=frameDatos, fg_color=Inner_Frame_Color, width=500, height=200)
    homeFrame.pack(fill="x", padx=20)
    checkbox_Home = ctk.CTkCheckBox(
        homeFrame,
        text="Activar home personalizada",
        command=checkbox_event_home,
        variable=check_var_home,
        onvalue="on",
        offvalue="off",
        text_color="#ffffff",
        fg_color=Button_Color,
        hover_color=Button_Hover_Color
    )
    checkbox_Home.grid(column=0, row=0)
    homeEnt = ctk.CTkEntry(homeFrame)
    homeEnt.grid(column=1, row=0, padx=(10, 0), sticky="nsew")
    homeEnt.configure(state="normal")
    responsive_grid(homeFrame)
    # Frame para los botones

        

    def button_event_crear():
        usuario = usunom.get().strip()
        contraseña = passwdent.get().strip()
        checkbox_event_GID()
        checkbox_event_UID()
        checkbox_event_home()

        
        Utils.validadUsuarioAltair(usuario,contraseña,boolGID, boolUID,boolHome,numGID,numUID,pathHome)
        Utils.crearUsuario(usuario,contraseña,boolGID,boolUID,boolHome,numGID,numUID,pathHome)
    
    def button_event_borrar():
        usuario = usunom.get().strip()
        Utils.borrarUsu(usuario)
    
    

    frameBotones = ctk.CTkFrame(master=frameDatos, fg_color=Inner_Frame_Color, width=500, height=200)
    frameBotones.pack(pady=(5, 10), expand=True, anchor="n")

    buttonCrear = ctk.CTkButton(frameBotones, text="Crear Usuario", command=button_event_crear, fg_color=Button_Color, hover_color=Button_Hover_Color, border_width=1, border_color=Border_Color)
    buttonCrear.pack(pady=20,padx=10, side="right")

    buttonBorrar = ctk.CTkButton(frameBotones, text="Borrar Usuario", command=button_event_borrar, fg_color=Button_Color, hover_color=Button_Hover_Color, border_width=1, border_color=Border_Color)
    buttonBorrar.pack(pady=20,padx=10, side="right")
    return main_frame


def setup_app_widgets_jose(main_frame):
    default_frame_set_up(main_frame)
    current_active_button("Jose")

    FrameTitulo = ctk.CTkLabel(
        main_frame,
        text="Equipo Vega ✨",
        text_color=Title_Color,
        font=xl_font,
    )

    FrameTitulo.pack(padx=20, anchor="center")

    crontab_frame = ctk.CTkFrame(
        master=main_frame,
        fg_color=Inner_Frame_Color,
        border_color=Border_Color,
        border_width=1,
    )

    crontab_frame.pack(expand=True, side="top", fill="both", padx=20, pady=40)

    # Creamos el frame de los botones
    frame_botones = ctk.CTkFrame(
        master=crontab_frame,
        fg_color=In_Inner_Frame_Color,
        border_width=1,
        border_color=Border_Color,
    )

    # Label y Entry para introducir el label_usuario del que vamos a modificar el cront
    label_usuario = ctk.CTkLabel(frame_botones, text="Usuario", font=xl_font, padx=20, pady=40)

    usuario = ctk.StringVar()
    usuario.set("jose")

    label_usuario_entry = ctk.CTkEntry(frame_botones, textvariable=usuario)

    def comprobar_usuario():
        if usuario.get().upper() != "JOSE":  # Lista de usuarios validos
            lanzar_error("Prueba con un usuario valido")
            return False
        return True

    def crear_ventana_secundaria():
        ventana = tk.Toplevel()
        ventana.wait_visibility()
        ventana.grab_set()
        ventana.geometry("900x500+450+250")
        ventana.resizable(0, 0)
        ventana.config(background=Outter_Frame_Color)
        ventana.title("Nueva Tarea")
        #ventana.iconbitmap(r"Assets/logo.ico") --> Mirar como salvar esto
        ventana.focus()
        return ventana

    # Botones para gestionar la tabla
    def boton_new():

        if not comprobar_usuario():
            return

        ventana_add_task = crear_ventana_secundaria()

        # Creamos el main_frame_s
        main_frame_s = ctk.CTkFrame(ventana_add_task)

        # Creamos el frame nombre y comando
        frame_name_comand = ctk.CTkFrame(main_frame_s)

        name = ctk.CTkLabel(
            frame_name_comand,
            text="Nombre:",
            font=lg_font,
            pady=20,
            padx=20,
        )
        nombre_tarea_str = ctk.StringVar()
        name_entry = ctk.CTkEntry(
            frame_name_comand,
            placeholder_text="Nombre tarea (opcional)",
            width=155,
            textvariable=nombre_tarea_str,
        )
        '''
        def validar_comandos(text):
            empieza_por_comando = text.split(" ", 1)[0]
            with open("comandos_disponibles.txt") as fichero_comandos:  # compgen -c | sort | uniq > comandos_disponibles.txt en nuestra Linux
                if empieza_por_comando in fichero_comandos.read().split("\n"):
                    comand_error.grid_forget()
                    return True
                comand_error.configure(text=f"Comando {empieza_por_comando} desconocido")
                comand_error.grid(row=2, column=2, sticky="w")
                return False
        '''
        comand = ctk.CTkLabel(
            frame_name_comand,
            text="Comando:",
            font=lg_font,
            pady=20,
            padx=20,
        )
        '''
        comand_error = ctk.CTkLabel(
            frame_name_comand,
            text="Comando:",
            font=("Roboto", 16),
            pady=20,
            padx=20,
            text_color="red",
        )
        '''
        comando_str = ctk.StringVar()
        comand_entry = ctk.CTkEntry(frame_name_comand, width=155, textvariable=comando_str)
        '''
        text_check = comand_entry.register(validar_comandos)
        comand_entry.configure(validate="focusout", validatecommand=(text_check, "%P"))
        '''
        # Creamos el frame_repeticiones
        frame_repetitions = ctk.CTkFrame(master=main_frame_s)

        # El frame_repetitions contiene a su vez dos frame
        frame_repetitions_menu = ctk.CTkFrame(master=frame_repetitions)

        frame_repetitions_opciones = ctk.CTkFrame(master=frame_repetitions, width=650, height=320)
        frame_repetitions_opciones.grid_propagate(False)

        # Componentes frame_repetitions_menu

        frecuencia = ctk.CTkLabel(
            frame_repetitions_menu,
            text="Frecuencia:",
            font=("Roboto", 25, "bold"),
            pady=10,
            padx=10,
        )

        radio_var = tk.IntVar(value=0)

        def radiobutton_event():
            clean_frame(frame_repetitions_opciones)

            if radio_var.get() == 1:
                create_repetition_simple_widgets()
            elif radio_var.get() == 2:
                create_repetition_personal_widgets()

            responsive_grid(frame_repetitions_opciones)

        radiobutton_simple = ctk.CTkRadioButton(
            frame_repetitions_menu,
            text="Simple",
            command=radiobutton_event,
            variable=radio_var,
            fg_color=Button_Color,
            hover_color=Button_Hover_Color,
            value=1,
        )

        radiobutton_personalizada = ctk.CTkRadioButton(
            frame_repetitions_menu,
            text="Personalizada",
            command=radiobutton_event,
            variable=radio_var,
            fg_color=Button_Color,
            hover_color=Button_Hover_Color,
            value=2,
        )

        result_entry = ctk.CTkEntry(frame_repetitions_menu, placeholder_text="Frecuencia final", width=160)
        result_entry.configure(state="disabled")

        # Opcion defaul
        imagen_def = ctk.CTkLabel(
            frame_repetitions_opciones,
            text="",
            bg_color="#000000",
            fg_color="#000000",
            image=ctk.CTkImage(
                dark_image=Image.open(r"Assets/LinuxImage.jpg"),
                size=(
                    frame_repetitions_opciones.cget("width"),
                    frame_repetitions_opciones.cget("height"),
                ),
            ),
        )
        imagen_def.grid(row=0, column=0)
        responsive_grid(frame_repetitions_opciones)

        # Opción simple
        radio_var_repetition = tk.StringVar()

        def set_repetition_simple():
            result_entry.configure(state="normal")
            result_entry.delete(0, "end")
            result_entry.insert(0, radio_var_repetition.get())
            result_entry.configure(state="disabled")

        def create_repetition_simple_widgets():
            hourly = ctk.CTkRadioButton(
                frame_repetitions_opciones,
                text="Cada hora",
                command=set_repetition_simple,
                variable=radio_var_repetition,
                value="Cada hora",
                fg_color=Button_Color,
                hover_color=Button_Hover_Color,
                font=lg_font
            )
            daily = ctk.CTkRadioButton(
                frame_repetitions_opciones,
                text="Cada dia",
                command=set_repetition_simple,
                variable=radio_var_repetition,
                value="Cada dia",
                fg_color=Button_Color,
                hover_color=Button_Hover_Color,
                font=lg_font
            )
            weekly = ctk.CTkRadioButton(
                frame_repetitions_opciones,
                text="Cada semana",
                command=set_repetition_simple,
                variable=radio_var_repetition,
                value="Cada semana",
                fg_color=Button_Color,
                hover_color=Button_Hover_Color,
                font=lg_font
            )
            monthly = ctk.CTkRadioButton(
                frame_repetitions_opciones,
                text="Cada mes",
                command=set_repetition_simple,
                variable=radio_var_repetition,
                value="Cada mes",
                fg_color=Button_Color,
                hover_color=Button_Hover_Color,
                font=lg_font
            )
            yearly = ctk.CTkRadioButton(
                frame_repetitions_opciones,
                text="Cada año",
                command=set_repetition_simple,
                variable=radio_var_repetition,
                value="Cada año",
                fg_color=Button_Color,
                hover_color=Button_Hover_Color,
                font=lg_font
            )

            daily.grid(row=1, column=0, sticky="w", pady=10, padx=10)
            hourly.grid(row=2, column=0, sticky="w", pady=10, padx=10)
            weekly.grid(row=3, column=0, sticky="w", pady=10, padx=10)
            monthly.grid(row=4, column=0, sticky="w", pady=10, padx=10)
            yearly.grid(row=5, column=0, sticky="w", pady=10, padx=10)

        # Opción personalizada

        def create_repetition_personal_widgets():
            minute = ctk.CTkLabel(
                frame_repetitions_opciones,
                text="Minutos:",
                font=lg_font,
            )
            minute_entry = ctk.CTkEntry(frame_repetitions_opciones, placeholder_text="0-59", width=55)

            hour = ctk.CTkLabel(
                frame_repetitions_opciones,
                text="Hora:",
                font=lg_font,
            )
            hour_entry = ctk.CTkEntry(frame_repetitions_opciones, placeholder_text="0-23", width=55)

            day = ctk.CTkLabel(
                frame_repetitions_opciones,
                text="Dia del mes:",
                font=lg_font,
            )
            day_entry = ctk.CTkEntry(frame_repetitions_opciones, placeholder_text="1-31", width=55)

            month = ctk.CTkLabel(
                frame_repetitions_opciones,
                text="Mes:",
                font=lg_font,
            )
            month_entry = ctk.CTkEntry(frame_repetitions_opciones, placeholder_text="1-12", width=55)

            dia_semana = ctk.CTkLabel(
                frame_repetitions_opciones,
                text="Dia señana:",
                font=lg_font,
            )
            dia_semana_entry = ctk.CTkEntry(frame_repetitions_opciones, placeholder_text="0-7", width=55)

            def set_repetition_personal():
                personalizada = minute_entry.get() + " " + hour_entry.get() + " " + day_entry.get() + " " + month_entry.get() + " " + dia_semana_entry.get()
                # Metodo valida personalizada retorna flag
                result_entry.configure(state="normal")
                result_entry.delete(0, "end")
                result_entry.insert(0, personalizada)
                result_entry.configure(state="disabled")

            set_parameter = ctk.CTkButton(
                frame_repetitions_opciones,
                text="Confirmar frecuencia",
                command=set_repetition_personal,
                fg_color=Button_Color,
                hover_color=Button_Hover_Color,
                border_width=1,
                border_color=Border_Color,
                font=lg_font) 
            

            minute.grid(row=0, column=0, sticky="w", pady=5, padx=5)
            minute_entry.grid(row=1, column=0, sticky="w", pady=5, padx=5)
            hour.grid(row=0, column=1, sticky="w", pady=5, padx=5)
            hour_entry.grid(row=1, column=1, sticky="w", pady=5, padx=5)
            day.grid(row=0, column=2, sticky="w", pady=5, padx=5)
            day_entry.grid(row=1, column=2, sticky="w", pady=5, padx=5)
            month.grid(row=0, column=3, sticky="w", pady=5, padx=5)
            month_entry.grid(row=1, column=3, sticky="w", pady=5, padx=5)
            dia_semana.grid(row=0, column=4, sticky="w", pady=5, padx=5)
            dia_semana_entry.grid(row=1, column=4, sticky="w", pady=5, padx=5)
            set_parameter.grid(row=2, column=3, sticky="we", columnspan=2, pady=50, padx=5)

        def add_task():
            task = taskC.Task(nombre_tarea_str.get(), f"{result_entry.get()} {comando_str.get()}")

            tv.insert(
                "",
                "end",
                text=task.get_nombre(),
                values=[task.get_comando(), task.get_frecuencia()]
            )

            ventana_add_task.destroy()

        confirmar_task = ctk.CTkButton(frame_repetitions_menu, text="Crear",
                                        command=add_task,
                                        width=120,
                                        fg_color=Button_Color,
                                        hover_color=Button_Hover_Color,
                                        border_width=1,
                                        border_color=Border_Color,
                                        font=lg_font)  # Mismo boton parra las dos opciones

        # Añadimos los componentes al frame_name_comand
        name.grid(row=1, column=0, sticky="w")
        name_entry.grid(row=1, column=1)

        comand.grid(row=2, column=0)
        comand_entry.grid(row=2, column=1, sticky="w")

        # Añadimos los frames al frame_repetitions
        frame_repetitions_menu.pack(expand=True, fill="both", side="left", padx=10, pady=10)
        frame_repetitions_opciones.pack(expand=True, fill="both", side="right", padx=10, pady=10)

        # Añadimos los componentes al frame_repetitions_menu
        frecuencia.grid(row=0, column=0, sticky="w")
        radiobutton_simple.grid(row=1, column=0, sticky="w", pady=10, padx=20)
        radiobutton_personalizada.grid(row=2, column=0, sticky="sw", pady=5, padx=20)
        result_entry.grid(row=3, column=0, sticky="nw", pady=10, padx=20)
        confirmar_task.grid(row=4, column=0, sticky="sw", pady=10, padx=20)

        # Añadimos los componentes al frame_repetitions_opciones -> radiobutton_event()

        # Añadimos los frame al main_frame
        frame_name_comand.pack(fill="both", side="top", padx=10, pady=10)
        frame_repetitions.pack(expand=True, fill="both", side="bottom", padx=10, pady=10)
        main_frame_s.pack(expand=True, fill="both")

    def boton_delete():
        if not comprobar_usuario():
            return
        if not tv.selection():
           lanzar_error("Error: ninguna fila seleccionada.")
        else:
            resultado = messagebox.askquestion(
                title="Confirmación",
                message="¿Seguro que quieres eliminar esta\\s task?",
            )
            if resultado == "yes":
                for x in tv.selection():
                    tv.delete(x)

    def boton_refrescar():
        if not comprobar_usuario():
            return
        # Limpia la tabla
        for i in tv.get_children():
            tv.delete(i)

        tasks = []

        for i in range(10):  # Leo de fichero
            task = taskC.Task(i, f"{i} * * * * rm -rf /")
            tasks.append(task)

        cargar_tabla(tabla=tv, lista_tasks=tasks)

    def boton_guardar():
        if not comprobar_usuario():
            return
        # Codigo para escribir en fichero del usuario las líneas de la tabla tv

    new_task = ctk.CTkButton(frame_botones, text="Nuevo", command=boton_new,fg_color=Button_Color, hover_color=Button_Hover_Color, border_width=1, border_color=Border_Color, font=lg_font)
    delete_task = ctk.CTkButton(frame_botones, text="Borrar", command=boton_delete,fg_color=Button_Color, hover_color=Button_Hover_Color, border_width=1, border_color=Border_Color, font=lg_font)
    refres_tv = ctk.CTkButton(frame_botones, text="Refrescar Tabla", command=boton_refrescar,fg_color=Button_Color, hover_color=Button_Hover_Color, border_width=1, border_color=Border_Color, font=lg_font)
    save_tv = ctk.CTkButton(frame_botones, text="Guardar en fichero", command=boton_guardar,fg_color=Button_Color, hover_color=Button_Hover_Color, border_width=1, border_color=Border_Color, font=lg_font)

    # Creamos la tabla
    frame_tabla = ctk.CTkFrame(master=crontab_frame)
    tv = tree_view.TreeViewEditable(frame_tabla, columns=("Comando", "Frecuencia"))

    # Definimos sus columnas
    tv.column("#0", anchor=tk.CENTER)  # Nombre de la task
    tv.column("Comando", anchor=tk.CENTER)  # Comando de la task
    tv.column("Frecuencia", anchor=tk.CENTER)  # Frecuencia de la task

    # Definimos sus cabeceras
    tv.heading("#0", text="  Nombre", anchor=tk.CENTER)
    tv.heading("Comando", text="Comando", anchor=tk.CENTER)
    tv.heading("Frecuencia", text="Frecuencia", anchor=tk.CENTER)

    label_usuario.grid(row=0, column=0, pady=2)
    label_usuario_entry.grid(row=0, column=1)

    new_task.grid(row=1, column=0)
    delete_task.grid(row=1, column=1)
    refres_tv.grid(row=1, column=2)
    save_tv.grid(row=1, column=3, pady=20)

    frame_botones.pack(expand=True, fill="both", side="top", padx=20, pady=20)
    responsive_grid(frame_botones)

    tv.pack(expand=True, fill="both")
    frame_tabla.pack(expand=True, fill="both", side="bottom", padx=20, pady=20)
    main_frame.pack(expand=True, fill="both")

    return main_frame

def SideBar(app, main_frame):
    global PeriodicCopyButton, InstantCopyButton, LDAPUsersButton, CronButton
    # Side menu frame
    side_menu_frame = ctk.CTkFrame(app, fg_color=SideBar_Color, corner_radius=0)
    side_menu_frame.pack(side="left", fill="y")

    # Iconpark Duotone Icons
    Icon_Size = (30, 30)
    PeriodicImagePath = r"Assets/PeriodicCopy.png"
    PeriodicImage = Image.open(PeriodicImagePath)
    PeriodicImage = PeriodicImage.resize(Icon_Size)
    PeriodicImage_tk = ctk.CTkImage(PeriodicImage)

    InstantCopyImagePath = r"Assets/InstantCopy.png"
    InstantCopyImage = Image.open(InstantCopyImagePath)
    InstantCopyImage = InstantCopyImage.resize(Icon_Size)
    InstantCopyImage_tk = ctk.CTkImage(InstantCopyImage)

    LDAPUsersImagePath = r"Assets/LDAPUsers.png"
    LDAPUsersImage = Image.open(LDAPUsersImagePath)
    LDAPUsersImage = LDAPUsersImage.resize(Icon_Size)
    LDAPUsersImage_tk = ctk.CTkImage(LDAPUsersImage)

    CronImagePath = r"Assets/Cron.png"
    CronImage = Image.open(CronImagePath)
    CronImage = CronImage.resize(Icon_Size)
    CronImage_tk = ctk.CTkImage(CronImage)

    # Crear los botones y colocarlos con grid()
    PeriodicCopyButton = ctk.CTkButton(
        side_menu_frame,
        text="Programar Copia de seguridad",
        image=PeriodicImage_tk,
        compound="left",
        command=lambda: setup_app_widgets_isaac(main_frame, 1),
        fg_color=SideBar_Button_Color,
        hover_color=SideBar_Active_Color,
        text_color="#f0f0f0",
        font=("Arial", 12, "bold"),
        corner_radius=0,
        height=58,
        anchor="w",  # Alinea el texto a la izquierda
    )
    PeriodicCopyButton.grid(row=0, column=0, sticky="ew")

    InstantCopyButton = ctk.CTkButton(
        side_menu_frame,
        text="Hacer Copia de seguridad",
        image=InstantCopyImage_tk,
        compound="left",
        command=lambda: setup_app_widgets_isaac(main_frame, 2),
        fg_color=SideBar_Button_Color,
        hover_color=SideBar_Active_Color,
        text_color="#f0f0f0",
        font=("Arial", 12, "bold"),
        corner_radius=0,
        height=58,
        anchor="w",  # Alinea el texto a la izquierda
    )
    InstantCopyButton.grid(row=1, column=0, sticky="ew")

    LDAPUsersButton = ctk.CTkButton(
        side_menu_frame,
        text="Gestión de usuarios",
        image=LDAPUsersImage_tk,
        compound="left",
        command=lambda: setup_app_widgets_ruben(main_frame),
        fg_color=SideBar_Button_Color,
        hover_color=SideBar_Active_Color,
        text_color="#f0f0f0",
        font=("Arial", 12, "bold"),
        corner_radius=0,
        height=58,
        anchor="w",  # Alinea el texto a la izquierda
    )
    LDAPUsersButton.grid(row=2, column=0, sticky="ew")

    CronButton = ctk.CTkButton(
        side_menu_frame,
        text="Programar una tarea en Cron",
        image=CronImage_tk,
        compound="left",
        command=lambda: setup_app_widgets_jose(main_frame),
        fg_color=SideBar_Button_Color,
        hover_color=SideBar_Active_Color,
        text_color="#f0f0f0",
        font=("Arial", 12, "bold"),
        corner_radius=0,
        height=58,
        anchor="w",  # Alinea el texto a la izquierda
    )
    CronButton.grid(row=3, column=0, sticky="ew")

    # Hacer que la columna 0 se estire para llenar todo el ancho disponible
    side_menu_frame.grid_columnconfigure(0, weight=1)

def initial_setup(app):
    global wrapper_frame
    # Marco principal con scroll
    wrapper_frame = ctk.CTkScrollableFrame(master=app, fg_color=Outter_Frame_Color,scrollbar_fg_color=Outter_Frame_Color,scrollbar_button_color=Outter_Frame_Color,scrollbar_button_hover_color=Outter_Frame_Color)
    wrapper_frame.pack(expand=True, fill="x", side="right")

    main_frame = ctk.CTkFrame(master=wrapper_frame, fg_color=Outter_Frame_Color)
    main_frame.pack(expand=True, fill="y", side="right")
    Welcome_Label = ctk.CTkLabel(
        master=main_frame,
        anchor="center",
        text="Bienvenidos a la App de ASO.",
        font=("Roboto", 50, "bold"),
        pady=15,
        padx=10,
    )
    Welcome_Label.pack()
    Paragraph_Label = ctk.CTkLabel(
        master=main_frame,
        anchor="center",
        text="Esta es una App desarollada por los alumnos de ASIR2, en la asignatura\n de Administración de sistemas operativos, coordinada por Félix.",
        font=("Roboto", 20, "bold"),
        pady=10,
        padx=10,
    )
    Paragraph_Label.pack()
    SideBar(app, main_frame)

    """
    WelcomeImage = ctk.CTkImage(light_image=Image.open(r"Assets/DefaultBg.png" ), size=(APP_DIMENSIONS['Width'], APP_DIMENSIONS['Height']))
    WelcomeLabel = ctk.CTkLabel(master=app, text="", image=WelcomeImage)
    WelcomeLabel.pack(side="top", expand=True)
    """
    return main_frame

def run_app():
    """
    Crea una instancia de la aplicación configurada.
    """
    # Inicialización de la aplicación
    app = ctk.CTk()
    app.geometry(f"{Screen_Width}x{Screen_Height}")
    app.minsize(Screen_Width,Screen_Height)

    app.title("Linux")
    app.configure(fg_color=Outter_Frame_Color)

    # Configuración inicial
    main_frame = initial_setup(app)

    # Lanzamiento de la aplicación
    app.mainloop()


if __name__ == "__main__":
   run_app()
