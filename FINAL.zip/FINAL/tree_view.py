import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkinter import messagebox

class TreeViewEditable(ttk.Treeview):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)

        self.bind("<Double-1>", self.doble_click)

        # Configuración del estilo
        style = ttk.Style(master=master)
        # Estilo para las celdas
        style.configure("Personalizado.Treeview", font=("Helvetica", 12), rowheight=30)
        # Estilo para los encabezados
        style.configure("Personalizado.Treeview.Heading", font=("Helvetica", 14, "bold"))

        # Aplicar el estilo al Treeview
        self.configure(style="Personalizado.Treeview")
        

        # Configurar las etiquetas para manejar el fondo de las filas
        self.tag_configure("oddrow", background="lightblue")
        self.tag_configure("evenrow", background="white")
        
    def doble_click(self, event):
        region_click = self.identify_region(event.x, event.y)
        if region_click in ("tree", "cell"):
            columna = int(self.identify_column(event.x)[1:]) - 1
            select_id = self.focus()
            select_values = self.item(select_id)

            if columna == -1:
                select_cell = select_values.get("text")
            else:
                select_cell = select_values.get("values")[columna]

            coordinates_box = self.bbox(item=select_id, column="#" + str(columna + 1))
            entry_edit = ttk.Entry(self.master, width=coordinates_box[2], justify=CENTER, font=("Helvetica", 15))

            entry_edit.editing_column_index = columna
            entry_edit.editing_item_id = select_id

            entry_edit.insert(0, select_cell)
            entry_edit.select_range(0, tk.END)
            entry_edit.focus()

            entry_edit.place(x=coordinates_box[0],
                            y=coordinates_box[1],
                            width=coordinates_box[2],
                            height=coordinates_box[3])

            entry_edit.bind("<FocusOut>", self.on_focus_out)
            entry_edit.bind("<Return>", self.editar)

    def on_focus_out(self, event):
        event.widget.destroy()

    def editar(self, event):
        new_text = event.widget.get()
        resultado = messagebox.askokcancel(title="Confirmar edición", message=f"Seguro que quieres editar: {new_text}")
        if resultado:
            column_index = event.widget.editing_column_index
            item_id = event.widget.editing_item_id

            if column_index == -1:
                self.item(item_id, text=new_text)
            else:
                selected_values = self.item(item_id).get("values")
                selected_values[column_index] = new_text
                self.item(item_id, values=selected_values)
            event.widget.destroy()


 
