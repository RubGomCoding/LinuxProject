import tkinter as tk
import customtkinter as ctk
from tkinter import ttk

class Task:
    def __init__(self, nombre, linea_fichero):
        self.nombre = nombre
        self.linea_fichero = str(linea_fichero).split(maxsplit=5, sep=' ') 
        self.comando = self.linea_fichero[5]
        self.frecuencia = self.linea_fichero[0:5]

    def get_nombre(self):
        return self.nombre
    
    def set_nombre(self,nombre):
        self.nombre = nombre
    
    def get_comando(self):
        return self.comando
    
    def set_nombre(self,comando):
        self.comando = comando

    def get_frecuencia(self):
        return self.frecuencia
    
    def set_frecuencia(self,frecuencia):
        self.frecuencia = frecuencia      

    def __str__(self):
        return f"Task de crontab con nombre: {self.nombre}, \n\tQue ejecuta el sigueinte comando: {self.comando}, \n \tCon la sigueinte frecuencia: {self.frecuencia}"